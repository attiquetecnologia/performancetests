let a = 1;
if (a == 1){
    console.log("Verdade");
}