const t0 = performance.now();
console.log("Hello World");
const t1 = performance.now();
console.log(`Call to doSomething took ${t1 - t0} milliseconds.`);
