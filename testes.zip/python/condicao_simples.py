a = 1
if a == 1:
    print("Verdade")